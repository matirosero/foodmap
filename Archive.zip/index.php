<?php
/*
FoodMap
[Home]

*/

$page = 'home';

include('blocks/header.php');
include('blocks/sidepanel.php');
include('blocks/main.php');
include('blocks/foodtrips.php');
include('blocks/footer.php');

?>