			<ul class="sidepanel-submenu ingredients">
				<li class="">
					<a href="" data-sidepanel-content="sub-generalinfo">
						<?php include('includes/icon-side-submenu-generalinfo.inc');?>
					</a>
				</li>
				<li class="">
					<a href="" data-sidepanel-content="sub-dishes">
						<?php include('includes/icon-side-submenu-dish.inc');?>
					</a>
				</li>
				<li class="">
					<a href="#" class="">

					</a>
				</li>
				<li class="">
					<a href="" class="">
						<?php include('includes/icon-side-submenu-tech.inc');?>
					</a>
				</li>
			</ul>
