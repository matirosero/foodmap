		<!-- #map-content -->
		<div id="map-content" role="map">

			<!-- #mapdiv -->
			<div id="mapdiv">
			</div><!-- /#mapdiv -->


			<?php include('blocks/searchbox.php'); ?>
			<?php include('blocks/firstvisit-box.php'); ?>
			<?php include('blocks/showinfo-box.php'); ?>

		</div><!-- /#map-content -->
