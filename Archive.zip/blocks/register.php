		<div id="register" class="global-container">
			<div class="form-container">

			<h2>Regístrate</h2>

			<form>
				<fieldset>
					<p>
						<label for="username">Nombre de usuario</label>
						<input type="text" name="username" />
					</p>
					<p>
						<label for="email">Correo electrónico o usuario</label>
						<input type="email" name="user" />
					</p>
					<p>
						<label for="password">Contraseña</label>
						<input type="password" name="password" />
					</p>
					<p>
						<label for="password-2">Confirmar Contraseña</label>
						<input type="password" name="password-2" />
					</p>

					<p>
						<button type="submit" name="register">Entrar</button>
					</p>
					<p>
						<input type="checkbox" name="remember" value="" />
						<label for="remember">Recordame en este ordenador</label>
				</fieldset>
			</form>

			</div>

		</div>