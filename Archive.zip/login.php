<?php
/*
FoodMap
[Login]

*/

$page = 'login';

include('blocks/header.php');
include('blocks/main.php');
include('blocks/footer.php');

?>